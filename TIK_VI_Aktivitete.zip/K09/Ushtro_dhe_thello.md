# Ushtro dhe thello — kapitulli 9

## Nga butoni te gjendja e rampës

Përdor modelin e rampës në MakeCode: X do të thotë mbyllur, kurse shenja e kontrollit do të thotë hapur.

### Niveli 1 — Baza

Provo nisjen dhe butonin A. Emërto hyrjen, veprimin e programit dhe daljen që sheh.

### Niveli 2 — Arsyeto dhe përmirëso

Provo A, A, B, B. Parashiko rezultatin pas secilës shtypje. Shpjego çfarë do të duhej kontrolluar veçmas në një pajisje fizike.

### Puno dhe bashkëpuno

**Hapi 1.** Hap projektin në simulator. Shëno gjendjen para çdo veprimi.

**Hapi 2.** Shtyp butonat sipas planit. Regjistro shenjën që shfaqet.

**Hapi 3.** Krahaso provën me pritjen dhe korrigjo programin vetëm nëse ka mospërputhje.

**Hapi 4.** Shpjego pse kjo është paraqitje me LED dhe jo rampë fizike funksionale apo sistem sigurie.

**Produkti që dorëzon:** Programi, tabela e gjendjeve dhe kufizimet e modelit.

**Lidhja me praktikën profesionale:** Tekniku i automatizimit dallon simulimin nga puna fizike. Ti ushtron lidhjen hyrje–përpunim–dalje dhe testimin.

Krahasoje rezultatin me kërkesën. Shpjego një zgjedhje dhe një përmirësim.
