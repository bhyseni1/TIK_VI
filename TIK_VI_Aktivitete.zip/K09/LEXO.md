# MakeCode

1. Hap https://makecode.microbit.org.
2. Zgjidh Import > Import File dhe ngarko rampa.hex.
3. Provo simulatorin: në nisje X, A jep shenjën e kontrollit, B jep X.
4. Për semafori.ts: krijo projekt, kalo te JavaScript, zëvendëso kodin me përmbajtjen e skedarit dhe kthehu te Blocks.
5. Ruaj kopjen me Download; kur kërkohet lidhje, përdor Download as File nëse nuk ke pajisje.

Rampa u provua në simulatorin MakeCode v9.0.12 më 14.11.2026 dhe skedari HEX u prodhua nga editori zyrtar. Nuk u provua në pajisje fizike. Semafori u kontrollua me mjedis testimi të thirrjeve të kodit; kërkon provën tënde në simulator. Asnjëri nuk është sistem për rrugë ose parking real.
