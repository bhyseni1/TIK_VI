basic.forever(function () {
    basic.showNumber(1)
    basic.pause(2000)
    basic.showNumber(2)
    basic.pause(1000)
    basic.showNumber(3)
    basic.pause(2000)
})
