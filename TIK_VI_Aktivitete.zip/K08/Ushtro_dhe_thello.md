# Ushtro dhe thello — kapitulli 8

## Provo lojën para se ta dorëzosh

Përdor lojën e kapitullit me pikë që rriten deri në pesë. Një lojë duhet të ketë rregulla të qarta dhe prova.

### Niveli 1 — Baza

Nise lojën, kliko një herë dhe shëno pikët. Nise sërish dhe kontrollo nëse pikët kthehen në zero.

### Niveli 2 — Arsyeto dhe përmirëso

Kliko gjashtë herë. Kontrollo që kufiri pesë të mos tejkalohet. Nëse ndodh, shqyrto kushtin dhe rendin e blloqeve.

### Puno dhe bashkëpuno

**Hapi 1.** Shkruaj tri pritje: në nisje 0, pas një klikimi 1, pas gjashtë klikimeve 5.

**Hapi 2.** Ekzekuto provat dhe shëno rezultatin e vëzhguar, edhe kur është ndryshe.

**Hapi 3.** Ndrysho vetëm pjesën që lidhet me gabimin. Ekzekuto përsëri të tri provat.

**Hapi 4.** Ruaj projektin dhe përshkruaj një ndryshim. Në Python provo edhe print(6 + 4) dhe shpjego daljen.

**Produkti që dorëzon:** Projekti i ruajtur dhe një tabelë me pritje, rezultat dhe përmirësim.

**Lidhja me praktikën profesionale:** Testuesi kërkon edhe rastet ku programi mund të dështojë. Ti ushtron durimin, provën dhe shpjegimin e kodit.

Krahasoje rezultatin me kërkesën. Shpjego një zgjedhje dhe një përmirësim.
