a = 3
b = 8
c = 5
kandidati = a
if b > kandidati:
    kandidati = b
if c > kandidati:
    kandidati = c
print(kandidati)
