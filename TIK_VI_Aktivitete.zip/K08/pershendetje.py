print("Përshëndetje, klasa VI!")
