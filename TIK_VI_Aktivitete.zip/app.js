'use strict';
const $=s=>document.querySelector(s);const bits=[0,0,0,0];
document.querySelectorAll('[data-bit]').forEach(btn=>btn.addEventListener('click',()=>{const i=Number(btn.dataset.bit);bits[i]=1-bits[i];btn.textContent=bits[i];btn.setAttribute('aria-pressed',bits[i]===1?'true':'false');$('#binary-result').textContent=bits.join('')+' = '+TIKVI.binary(bits); }));
document.querySelectorAll('[data-ramp]').forEach(btn=>btn.addEventListener('click',()=>{$('#ramp-result').textContent='Gjendja: '+TIKVI.ramp(btn.dataset.ramp);}));
$('#chapter-select').addEventListener('change',event=>{document.querySelectorAll('.chapter').forEach(c=>c.hidden=event.target.value!=='all'&&c.dataset.chapter!==event.target.value);});
$('#check-data').addEventListener('click',()=>{const r=TIKVI.stats([12,9,15,10,14]);$('#data-result').textContent=`Shuma: ${r.sum}; mesatarja: ${r.mean}; minimumi: ${r.min}; maksimumi: ${r.max}.`;});
