# Ushtro dhe thello — kapitulli 10

## Portofoli: shkolla inteligjente dhe e qëndrueshme

Zgjidh një nevojë të vogël shkollore, si organizimi i materialeve ose kujdesi për pajisjet. Përgatit një zgjidhje të dokumentuar.

### Niveli 1 — Baza

Krijo një dokument me nevojën, tri kërkesa dhe produktin. Shëno burimet e tekstit dhe të çdo figure.

### Niveli 2 — Arsyeto dhe përmirëso

Lidh dokumentin me një tabelë dhe një program ose model. Analizo nëse AI-ja nevojitet vërtet. Shpjego privatësinë, kufizimet dhe ndikimin mjedisor.

### Puno dhe bashkëpuno

**Hapi 1.** Ndani rolet: planifikues, krijues, kontrollues. Secili shënon punën e vet.

**Hapi 2.** Krijoni produktin pa të dhëna personale. Etiketoni të dhënat mësimore dhe çdo përdorim të AI-së.

**Hapi 3.** Provoni tri raste. Ruani rezultatin e pritur dhe atë të vëzhguar; mos shkruani se funksionon pa e provuar.

**Hapi 4.** Prezantoni nevojën, zgjidhjen, provat dhe një përmirësim. Dalloni çfarë realizuat nga ajo që vetëm propozoni.

**Produkti që dorëzon:** Portofol me dokument, tabelë, program ose model, burime dhe regjistër provash.

**Lidhja me praktikën profesionale:** Ekipi profesional dokumenton kontributin dhe kufizimet. Ti lidh krijimtarinë me përgjegjësinë digjitale.

Krahasoje rezultatin me kërkesën. Shpjego një zgjedhje dhe një përmirësim.
