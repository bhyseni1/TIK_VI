# Shkolla inteligjente dhe e qëndrueshme

## Nevoja
Shkruaj një nevojë konkrete.

## Tri kërkesa
1.
2.
3.

## Rolet dhe kontributi
Përdor etiketa grupi, jo të dhëna personale në publik.

## Produktet
Dokumenti, tabela, programi ose modeli, prezantimi.

## Provat
Plotëso regjistri_provave.csv me rezultate që i vëzhgon realisht.

## Burimet dhe kufizimet
Shëno çfarë u simulua dhe çfarë u provua fizikisht.
