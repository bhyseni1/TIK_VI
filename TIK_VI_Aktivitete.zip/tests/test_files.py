import unittest,subprocess,sys,json,zipfile,csv,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
class Files(unittest.TestCase):
 def test_python_outputs(self):
  for f,expected in [('K08/pershendetje.py','Përshëndetje, klasa VI!'),('K08/shuma.py','10'),('K08/maksimumi.py','8'),('K04/analiza.py','Shuma: 60\nMesatarja: 12.0\nMinimumi: 9\nMaksimumi: 15')]:
   self.assertEqual(subprocess.check_output([sys.executable,str(ROOT/f)],text=True).strip(),expected)
 def test_csv(self):
  with (ROOT/'K04/flete_shembull.csv').open() as f:rows=list(csv.DictReader(f))
  self.assertEqual(sum(int(r['Flete']) for r in rows),60)
 def test_scratch_structure(self):
  with zipfile.ZipFile(ROOT/'K08/loja_pese_klikime.sb3') as z:
   p=json.loads(z.read('project.json'));self.assertEqual(len(p['targets']),2)
   for target in p['targets']:
    for co in target['costumes']:self.assertEqual(hashlib.md5(z.read(co['md5ext'])).hexdigest(),co['assetId'])
    for bid,b in target['blocks'].items():
     if b['next']:self.assertIn(b['next'],target['blocks'])
     if b['parent']:self.assertIn(b['parent'],target['blocks'])
 def test_units(self):
  self.assertEqual(sum(len(list((ROOT/f'K{i:02d}').glob('[0-9]*.md'))) for i in range(1,11)),167)
if __name__=='__main__':unittest.main()
