const test=require('node:test');const assert=require('node:assert/strict');const fs=require('node:fs');const vm=require('node:vm');const {binary,stats,ramp}=require('../logic.js');
test('të 16 paraqitjet binare',()=>{for(let n=0;n<16;n++)assert.equal(binary(n.toString(2).padStart(4,'0').split('').map(Number)),n);});
test('hyrje të pavlefshme',()=>{assert.throws(()=>binary([0,2,0,1]));assert.throws(()=>stats([]));assert.throws(()=>ramp('C'));});
test('statistikat e shembullit',()=>assert.deepEqual(stats([12,9,15,10,14]),{sum:60,mean:12,min:9,max:15}));
test('rampa A B dhe nisja',()=>{assert.equal(ramp('start'),'mbyllur');assert.equal(ramp('A'),'hapur');assert.equal(ramp('B'),'mbyllur');});
test('kodi MakeCode rampa: ngjarjet',()=>{const icons=[];const handlers={};vm.runInNewContext(fs.readFileSync('K09/rampa.ts','utf8'),{basic:{showIcon:x=>icons.push(x)},IconNames:{No:'X',Yes:'check'},Button:{A:'A',B:'B'},input:{onButtonPressed:(b,fn)=>handlers[b]=fn}});handlers.A();handlers.B();assert.deepEqual(icons,['X','check','X']);});
test('kodi MakeCode semafori: një cikël',()=>{const calls=[];vm.runInNewContext(fs.readFileSync('K09/semafori.ts','utf8'),{basic:{forever:fn=>fn(),showNumber:n=>calls.push(['number',n]),pause:n=>calls.push(['pause',n])}});assert.deepEqual(calls,[['number',1],['pause',2000],['number',2],['pause',1000],['number',3],['pause',2000]]);});
