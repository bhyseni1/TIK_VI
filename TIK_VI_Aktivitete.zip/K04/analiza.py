"""Të dhëna mësimore të sajuara, jo matje reale."""
vlerat = [12, 9, 15, 10, 14]
print("Shuma:", sum(vlerat))
print("Mesatarja:", sum(vlerat) / len(vlerat))
print("Minimumi:", min(vlerat))
print("Maksimumi:", max(vlerat))
