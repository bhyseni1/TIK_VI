# Ushtro dhe thello — kapitulli 4

## Një vendim i mbështetur në tabelë

Përdor vlerat mësimore 12, 9, 15, 10, 14 për pesë ditë. Këto nuk janë matje reale të klasës.

### Niveli 1 — Baza

Shkruaj ditët dhe vlerat në dy kolona. Gjej shumën me formulë dhe kontrolloje me llogaritje në fletore.

### Niveli 2 — Arsyeto dhe përmirëso

Llogarit mesataren, minimumin dhe maksimumin. Ndërto grafik shtyllor dhe shpjego pse një grafik nuk provon shkakun e ndryshimit.

### Puno dhe bashkëpuno

**Hapi 1.** Shëno mbi tabelë: Shembull mësimor. Emërto kolonat Dita dhe Vlera.

**Hapi 2.** Vendos formulat në qeliza të veçanta dhe kontrollo intervalet.

**Hapi 3.** Krijo grafikun, vendos titull dhe emërto boshtet. Mos shpik njësi matëse që nuk janë dhënë.

**Hapi 4.** Shkruaj dy përfundime që dalin nga tabela dhe një pyetje që ajo nuk e përgjigjet.

**Produkti që dorëzon:** Tabela, formulat, grafiku dhe dy përfundime të kontrollueshme.

**Lidhja me praktikën profesionale:** Analisti lidh përfundimin me të dhënat. Ti ushtron llogaritjen, verifikimin dhe kufizimin e pretendimeve.

Krahasoje rezultatin me kërkesën. Shpjego një zgjedhje dhe një përmirësim.
