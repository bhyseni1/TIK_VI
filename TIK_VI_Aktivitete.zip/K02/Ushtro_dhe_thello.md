# Ushtro dhe thello — kapitulli 2

## Kartela e një kompjuteri të shkollës

Shkolla dëshiron një kartelë të kuptueshme për pajisjen që përdorni. Mblidh vetëm të dhëna që lejohen të shihen.

### Niveli 1 — Baza

Emërto dy pajisje hyrëse dhe dy dalëse. Shëno funksionin e secilës dhe provo një veprim të sigurt.

### Niveli 2 — Arsyeto dhe përmirëso

Shpjego pse RAM-i dhe ruajtja afatgjatë kanë role të ndryshme. Nëse sistemi tregon kapacitetet, shëno edhe njësinë dhe burimin.

### Puno dhe bashkëpuno

**Hapi 1.** Vëzhgo pajisjen pa e hapur. Shëno llojin dhe pjesët e dukshme.

**Hapi 2.** Me lejen e mësimdhënësit hap informacionin e sistemit. Mos ndrysho cilësime.

**Hapi 3.** Krahaso atë që vërehet nga jashtë me atë që raporton sistemi. Shëno çfarë nuk mund ta përcaktosh.

**Hapi 4.** Përgatit kartelën dhe kërko kontrollin e një shoku.

**Produkti që dorëzon:** Kartelë me pjesë, funksion, burim dhe një kufizim të vëzhgimit.

**Lidhja me praktikën profesionale:** Tekniku dokumenton para se të ndërhyjë. Ti ushtron përshkrimin e saktë dhe kujdesin ndaj pajisjeve.

Krahasoje rezultatin me kërkesën. Shpjego një zgjedhje dhe një përmirësim.
