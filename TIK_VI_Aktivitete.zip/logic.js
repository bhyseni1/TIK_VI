(function(root){
'use strict';
function binary(bits){if(!Array.isArray(bits)||bits.length!==4||bits.some(b=>b!==0&&b!==1))throw Error('Kërkohen katër bitë 0/1.');return bits.reduce((s,b,i)=>s+b*2**(3-i),0);}
function stats(values){if(!Array.isArray(values)||!values.length||values.some(v=>!Number.isFinite(v)))throw Error('Kërkohen numra.');const sum=values.reduce((a,b)=>a+b,0);return {sum,mean:sum/values.length,min:Math.min(...values),max:Math.max(...values)};}
function ramp(action){if(!['start','A','B'].includes(action))throw Error('Veprim i panjohur');return action==='A'?'hapur':'mbyllur';}
const api={binary,stats,ramp};if(typeof module!=='undefined'&&module.exports)module.exports=api;else root.TIKVI=api;
})(typeof window!=='undefined'?window:globalThis);
