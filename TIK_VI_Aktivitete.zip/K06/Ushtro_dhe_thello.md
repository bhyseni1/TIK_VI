# Ushtro dhe thello — kapitulli 6

## Projekto një kënd leximi

Paraqit një ide për një kënd leximi. Mund të punosh në letër kur programi nuk është i disponueshëm.

### Niveli 1 — Baza

Vizato pamjen nga lart. Emërto të paktën tri objekte dhe shëno njësinë e përmasave të zgjedhura.

### Niveli 2 — Arsyeto dhe përmirëso

Ndërto ose përshkruaj një model 3D. Kontrollo nëse objekti i njëjtë ka përmasa të përputhshme në pamjet e ndryshme.

### Puno dhe bashkëpuno

**Hapi 1.** Shkruaj nevojën dhe dy kërkesa, për shembull qasje e lirë dhe vend për libra.

**Hapi 2.** Krijo skicën. Shëno nëse përmasat janë të matura me leje apo të zgjedhura për ushtrim.

**Hapi 3.** Shto përmasa dhe etiketa. Mos e paraqit skicën si plan ndërtimor të miratuar.

**Hapi 4.** Kërko një sugjerim nga shoku dhe paraqit versionin para dhe pas ndryshimit.

**Produkti që dorëzon:** Skica ose modeli me përmasa, kërkesa dhe një përmirësim të shpjeguar.

**Lidhja me praktikën profesionale:** Projektuesi provon ide dhe dokumenton ndryshimet. Ti ushtron mendimin hapësinor dhe kontrollin e kërkesave.

Krahasoje rezultatin me kërkesën. Shpjego një zgjedhje dhe një përmirësim.
