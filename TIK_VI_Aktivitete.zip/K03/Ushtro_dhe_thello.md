# Ushtro dhe thello — kapitulli 3

## Udhëzuesi digjital i klasës

Krijo një dokument të shkurtër që i tregon një nxënësi të ri si organizohen skedarët e lëndës.

### Niveli 1 — Baza

Krijo një titull, një paragraf dhe një listë me tri hapa. Ruaje dokumentin në dosjen e saktë dhe hape përsëri.

### Niveli 2 — Arsyeto dhe përmirëso

Shto një tabelë dosje–përmbajtje dhe një fotografi të lejuar me burimin. Eksporto PDF dhe kontrollo leximin e tij.

### Puno dhe bashkëpuno

**Hapi 1.** Planifiko përmbajtjen në fletore. Përdor emra dosjesh që i kupton edhe një person tjetër.

**Hapi 2.** Ndërto dokumentin në Writer ose në mjetin që përdor klasa. Përdor stile për titujt.

**Hapi 3.** Krijo tri slajde që paraqesin idenë kryesore, shembullin dhe përfundimin.

**Hapi 4.** Jepja skedarët një shoku. Kërko që t’i hapë dhe të gjejë një informacion pa ndihmën tënde.

**Produkti që dorëzon:** Dokumenti i redaktueshëm, PDF-ja dhe prezantimi që hapen pa gabim.

**Lidhja me praktikën profesionale:** Përgatitësi i përmbajtjes kujdeset për lexuesin. Ti ushtron shkrimin e qartë, organizimin dhe citimin.

Krahasoje rezultatin me kërkesën. Shpjego një zgjedhje dhe një përmirësim.
