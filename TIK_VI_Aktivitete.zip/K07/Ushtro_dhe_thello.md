# Ushtro dhe thello — kapitulli 7

## Një algoritëm që mund ta ndjekë shoku

Krijo një mënyrë për të gjetur numrin më të madh nga tre numra të dhënë.

### Niveli 1 — Baza

Përdor numrat 3, 8, 5. Shkruaj hapat dhe ndiqi me laps. Shëno vlerën që ruan pas çdo krahasimi.

### Niveli 2 — Arsyeto dhe përmirëso

Provo edhe 7, 7, 2 dhe 2, 5, 9. Shpjego si e trajton barazinë dhe pse rendi i numrave nuk duhet të prishë rezultatin.

### Puno dhe bashkëpuno

**Hapi 1.** Shëno hyrjet a, b, c. Vendos fillimisht me_i_madhi = a.

**Hapi 2.** Krahaso b me vlerën e ruajtur; ndryshoje vetëm nëse b është më i madh. Bëj të njëjtën gjë me c.

**Hapi 3.** Jepja udhëzimet shokut pa i treguar përgjigjen. Ai duhet të shënojë çdo hap.

**Hapi 4.** Krahasoni daljen e pritshme me atë të gjetur. Ndryshoni udhëzimin nëse është i paqartë.

**Produkti që dorëzon:** Algoritmi dhe tri raste prove, përfshirë rastin e barazisë.

**Lidhja me praktikën profesionale:** Programuesi e kontrollon zgjidhjen me raste të ndryshme. Ti ushtron zbërthimin, logjikën dhe arsyetimin.

Krahasoje rezultatin me kërkesën. Shpjego një zgjedhje dhe një përmirësim.
