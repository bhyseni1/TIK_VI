# TIK VI

Materiale për nxënësit e klasës VI, sipas librit me 140 faqe A4, 10 kapituj dhe 167 njësi. Autor i projektit: Besart Hyseni.

## Fillo

1. Në GitHub zgjidh Code > Download ZIP.
2. Nxirr të gjithë skedarët nga ZIP-i.
3. Hap index.html me shfletues. Hap K01–K10 për udhëzimet dhe skedarët.
4. Instalo LibreOffice, Scratch dhe Thonny me ndihmën e mësimdhënësit; MakeCode hapet në shfletues.
5. Ruaj produktet e tua në një kopje të veçantë.

Skedarët .md hapen si tekst. .csv hapen në Calc me ndarës presje. .py hapen në Thonny; shtyp F5. .sb3 hapet përmes File > Load from your computer në Scratch. rampa.hex importohet në MakeCode me Import File. Nuk kërkohet llogari personale nxënësi në GitHub ose Render.

## Verifikimi

Lexo QA.md për çfarë u testua dhe çfarë mbetet. Të dhënat numerike të shembujve janë mësimore të sajuara, jo rezultate matjesh. Modeli i rampës nuk kontrollon pajisje fizike dhe nuk është sistem sigurie.

## Zhvillimi dhe Render

Kërkohet Node.js i mbështetur. Provo `node --test tests/logic.test.cjs` dhe `python3 -m unittest discover -s tests -p 'test_*.py'`. Ndërto me `node scripts/build.mjs`. Publiko dosjen `dist` si Static Site. render.yaml përmban konfigurimin për emrin TIK_VI; hapësira e përdoruesit në Render duhet zgjedhur para krijimit.

Libri A4 dhe projekti LaTeX mirëmbahen veçmas në Overleaf. Ky depo përmban udhëzimet dhe aktivitetet, jo kopjet e librave të palëve të treta.

Çdo dosje K01–K10 përmban edhe **Ushtro_dhe_thello.md**: një aktivitet me dy nivele, hapa pune, produkt dhe lidhje me praktikën profesionale. Këto 10 aktivitete përforcuese i shtohen udhëzimeve të njësive; numërimi i njësive mbetet i pandryshuar.
