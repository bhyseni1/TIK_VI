import {mkdir,copyFile,cp,rm} from 'node:fs/promises';
await rm('dist',{recursive:true,force:true});await mkdir('dist');
for(const f of ['index.html','style.css','logic.js','app.js','README.md','QA.md'])await copyFile(f,'dist/'+f);
for(let n=1;n<=10;n++){const d='K'+String(n).padStart(2,'0');await cp(d,'dist/'+d,{recursive:true});}
console.log('TIK_VI: dist gati.');
