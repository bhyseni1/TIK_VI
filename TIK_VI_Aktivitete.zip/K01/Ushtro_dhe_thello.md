# Ushtro dhe thello — kapitulli 1

## Harta e teknologjisë së ditës sime

Zgjidh një detyrë nga shtëpia ose shkolla. Përshkruaj si mund të kryhet me dhe pa pajisje digjitale.

### Niveli 1 — Baza

Përmend dy pajisje. Për secilën shëno një hyrje dhe një dalje. Shpjego me një fjali çfarë pune të ndihmon të kryesh.

### Niveli 2 — Arsyeto dhe përmirëso

Krahaso dy zgjidhje për të njëjtën detyrë. Arsyeto zgjedhjen duke përdorur kohën, qasjen dhe privatësinë. Përshkruaj edhe një kufizim.

### Puno dhe bashkëpuno

**Hapi 1.** Vizato në fletore një tabelë: Detyra | Pajisja | Përfitimi | Kujdesi.

**Hapi 2.** Plotëso tri rreshta nga vëzhgimi yt. Mos shëno emra ose të dhëna private.

**Hapi 3.** Ndërroje tabelën me një shok. Ai zgjedh një rresht dhe të pyet pse e ke zgjedhur pajisjen.

**Hapi 4.** Përmirëso një rresht pas diskutimit. Shëno ndryshimin.

**Produkti që dorëzon:** Tabela me tri detyra dhe një zgjedhje të arsyetuar.

**Lidhja me praktikën profesionale:** Profesionisti fillon duke kuptuar nevojën. Ti ushtron vëzhgimin, komunikimin dhe zgjedhjen e një mjeti të përshtatshëm.

Krahasoje rezultatin me kërkesën. Shpjego një zgjedhje dhe një përmirësim.
