# Ushtro dhe thello — kapitulli 5

## Kontrollo para se të ndash

Për një temë mësimore gjej dy burime dhe përgatit një shënim për grupin. Mos dërgo mesazhe jashtë klasës.

### Niveli 1 — Baza

Shëno titullin, autorin ose institucionin dhe lidhjen e secilit burim. Dallo një fakt nga një opinion.

### Niveli 2 — Arsyeto dhe përmirëso

Krahaso datën, provat dhe qëllimin e dy burimeve. Shpjego një mospërputhje ose një kufizim. Kontrollo kush mund ta shohë dokumentin e përbashkët.

### Puno dhe bashkëpuno

**Hapi 1.** Shkruaj pyetjen që dëshiron të sqarosh dhe dy fjalë kyçe.

**Hapi 2.** Hap burimet. Lexo përmbajtjen përkatëse, jo vetëm titullin ose përmbledhjen e kërkimit.

**Hapi 3.** Përgatit një draft me përfundimin dhe dy lidhjet. Shëno çfarë mbetet e pasigurt.

**Hapi 4.** Me mësimdhënësin kontrollo lejet e ndarjes. Në mungesë llogarie shkollore, puno lokalisht dhe shpjego lejet me fjalë.

**Produkti që dorëzon:** Kartela e dy burimeve dhe një draft i qartë me burime.

**Lidhja me praktikën profesionale:** Komunikuesi i përgjegjshëm verifikon para publikimit. Ti ushtron kërkimin, bashkëpunimin dhe privatësinë.

Krahasoje rezultatin me kërkesën. Shpjego një zgjedhje dhe një përmirësim.
